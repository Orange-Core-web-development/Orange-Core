# Asset and licence notes

All five SVG assets in `assets/` were authored specifically for this fictional portfolio concept. They are original vector illustrations created for FREQ. Live Systems; no stock photography, external icon package, 3D model, paid asset, remote font or third-party runtime library is included.

- `freq-mark.svg` — original FREQ. monogram/wordmark graphic.
- `hero-stage.svg` — original abstract live-stage illustration with truss, beams and screen geometry.
- `audio-wave.svg` — original waveform and speaker illustration.
- `lighting-rig.svg` — original lighting and truss illustration.
- `site-plan.svg` — original top-down event/site-plan illustration.

**Third-party attribution:** None required. CSS uses system font stacks. The research report links to third-party guidance and competitor pages for research only; their logos, images and text are not reproduced in the site assets.
