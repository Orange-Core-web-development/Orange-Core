# FREQ. Live Systems — Day 13 portfolio website

**Niche:** Live event technical production and staging.  
**Fictional base:** Makeni, Lusaka, Zambia.  
**Tagline:** Make the room feel something.

> FREQ. Live Systems is a fictional portfolio concept. The business, contacts, location, team, inventory, project examples, testimonials and policies are invented. It is not a real production supplier and must not be used to solicit payments or real work.

## Pages
- `index.html` — positioning, capability overview, event formats and selected fictional work.
- `services.html` — filterable technical catalogue: audio, lighting, stage/rigging, video, power and show operations.
- `formats.html` — event-format pathways for corporate, conferences, festivals, brand activations and private events.
- `work.html` — three clearly labelled fictional production case studies.
- `approach.html` — discovery, site review, technical design, pre-production, show-call and strike; safety and venue-readiness notes.
- `brief.html` — local technical-brief builder with validation, copy and TXT download.

## File structure
```text
013-freq-live/
├── index.html
├── services.html
├── formats.html
├── work.html
├── approach.html
├── brief.html
├── styles.css
├── script.js
├── research.md
├── README.md
├── QA.md
├── ASSET-LICENSES.md
└── assets/
    ├── freq-mark.svg
    ├── hero-stage.svg
    ├── audio-wave.svg
    ├── lighting-rig.svg
    └── site-plan.svg
```

## Preview locally
No package manager or build step is needed:
```bash
python3 -m http.server 8000
```
Open http://localhost:8000.

## GitHub Pages
The website uses relative paths and plain HTML/CSS/JavaScript. To publish it independently, copy the contents of this folder into the root of a dedicated repository or a `/docs` folder configured as the Pages source. GitHub Pages does not publish an arbitrary nested portfolio directory by default without a deployment workflow. Keep relative paths intact.

## Interactions
- Responsive navigation with accessible expanded state.
- Service and event-format filters.
- Scroll reveals with `prefers-reduced-motion` fallback.
- Project brief validation and local summary generation.
- Copy-to-clipboard and `.txt` download.
- Native FAQ disclosures and keyboard focus states.

The enquiry builder does not send data to a server, send email or store personal information. It generates a local demonstration brief only.

## Fictional business brief
FREQ. is imagined as a technical event-production studio based in Makeni, Lusaka, serving Lusaka and selected Zambian destinations by project arrangement. Proposed disciplines include PA/audio, lighting, modular staging and rigging coordination, LED/video, temporary power planning, technical direction, operators and show crew.

**Positioning:** A technical partner for live experiences, with a clear path from first brief to site review, production plan, show-call and strike. The concept deliberately avoids unsupported claims about fleet size, client count, safety records or equipment brands.

**Fictional contacts:** `hello@freq.example`, `+260 000 000 000`. These are non-operational placeholders.

**Fictional proof:** All case studies and testimonial-style quotes are explicitly labelled as fictional concept studies. They are not endorsements or real event records.

## Important real-world limitations
- The site is a design demonstration, not a safety plan or technical specification.
- Final rigging, temporary structures, electrical distribution, crowd/site design and emergency arrangements require competent people, venue coordination and applicable local approvals.
- HSE and Event Safety Alliance links in `research.md` are reference guidance, not Zambian legal advice or proof of compliance.
- Permit/licence needs depend on event activities and jurisdiction. Confirm current requirements with the relevant Zambian authorities and venue.
- No real licences, insurance, professional registrations, inventory, client relationships, safety records, warranties or project statistics are claimed.

See `research.md` for the niche report, competitor observations, sourced facts, assumptions and source links.
