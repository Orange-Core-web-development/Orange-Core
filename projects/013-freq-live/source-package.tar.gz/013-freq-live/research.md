# Day 13 research — live event technical production & staging

**Research date:** 27 November 2026  
**Market lens:** Lusaka, Zambia, with regional project mobilisation where feasible  
**Niche boundary:** The technical layer of live events: audio, lighting, staging/rigging, LED/video, temporary power, show control and technical crew. This is distinct from full event planning, décor, catering, artist booking and venue management.

## 1. Niche overview

Live-event technical production translates an event brief, venue and running order into a safe, intelligible and engaging technical environment. The work is project-based and often combines equipment hire with design, transport, installation, operation and dismantling. A customer may buy one discipline (for example, conference audio) or a coordinated package spanning several systems.

The local market is not a blank slate. Public-facing Zambian providers describe integrated sound, lighting, stage, LED/video and technical production services. That makes a differentiated portfolio website less about claiming to be the only full-service provider and more about showing the planning method, technical scope, clarity of deliverables and evidence discipline.

## 2. Customer types and buying motivations

| Customer | Typical brief | Main buying motivations |
|---|---|---|
| Corporate communications / marketing teams | AGM, launch, awards night, town hall | Clear speech, brand visibility, dependable schedule, one accountable technical lead |
| Conference organisers / PCOs | Multi-session conference, hybrid presentation | Speech intelligibility, presenter confidence, screen visibility, fast room changeovers |
| Promoters / festival producers | Concert, festival, roadshow | Audience coverage, stage workflow, lighting impact, show-call coordination, weather and power planning |
| Venues / hotels | In-house or overflow technical support | Compatibility with house systems, safe rigging, predictable load-in/out |
| Agencies / creative studios | Brand activation, product reveal, experiential installation | Precise creative execution, content playback, cue timing and brand consistency |
| Couples / private hosts | Wedding, celebration, private concert | Good sound, atmosphere, discreet setup, clear package scope and calm coordination |
| NGOs / institutions | Public dialogue, community event, ceremony | Accessible speech, practical site logistics, documented responsibilities and cost clarity |

Customers are generally buying reduced event-day uncertainty as much as hardware. Useful website content should therefore explain the process, what information is needed for a quote, which services are bundled, and what is outside scope.

## 3. Common services and products

- **Audio:** PA systems, subwoofers, stage monitors, digital mixing, microphones, playback, RF coordination and front-of-house operation.
- **Lighting:** LED wash and profile fixtures, moving lights, control desks, DMX programming, stage and room looks.
- **Stage and rigging:** modular decks, stairs, ramps, truss, ground-support structures, scenic masking and approved suspension systems.
- **Video:** LED display surfaces, projection, confidence monitors, cameras, playback and switching.
- **Power:** load schedules, generator interface, distribution, cable routes, protection and backup planning.
- **Show control and crew:** technical direction, stage management interface, cue sheets, operators, technicians, load-in, rehearsal, show-call and strike.
- **Dry hire:** equipment-only rental may be offered, but compatibility, collection/return, operator responsibility and damage terms need to be explicit.

These are market-category observations drawn from provider service menus; they are not a claim that every supplier owns every item or offers every discipline.

## 4. Buying conventions and trust signals

A strong technical enquiry usually needs: event date and access times; venue and room/site dimensions; indoor/outdoor status; expected audience and seating format; event type; running order; number of microphones/presenters/performers; screen/content needs; power availability; rigging points or restrictions; and a budget range.

Trust signals that can be substantiated include:

- A named technical contact and clear project stages.
- A site visit or venue technical review for complex builds.
- An equipment schedule or scope matrix rather than vague “full package” language.
- A load-in, rehearsal, show-call and strike plan.
- A power and cable-routing plan, weather contingency for outdoor work, and a documented rigging approach.
- Crew roles and escalation contacts.
- Genuine project photographs, client permissions and specific case-study details.
- Written exclusions, overtime rules, cancellation terms and payment milestones.
- Relevant insurance, training, inspection records and licences only where the business can actually prove them.

Avoid fabricated client logos, inflated audience numbers, “100% safety” promises and unverified equipment brands or inventory counts.

## 5. Useful website features

1. Filterable service catalogue that separates audio, lighting, stage/rigging, video, power and show operations.
2. Event-format pages for corporate, conference, festival, brand activation and private events.
3. Case studies that identify the brief, venue constraints, production response and deliverables; fictional studies must be visibly labelled.
4. A clear planning process with the information required before quoting.
5. A practical technical brief builder that generates a local summary for the client to send through their preferred channel.
6. A site-readiness checklist covering access, audience layout, power, weather, rigging and venue rules.
7. FAQ and sample terms for equipment hire, crew, deposits, overtime and cancellation.
8. A direct phone/email contact path for real businesses; for this portfolio concept, all contact details remain non-operational placeholders.

## 6. Competitor and reference observations

These observations come from publicly accessible company pages and directories, not independent service audits:

- **Soundwave Zambia** publicly groups stage management, sound, lighting, visual/LED and stage/truss work, and shows examples across corporate, concert and festival contexts. This indicates that customers may expect a joined-up technical offer rather than isolated equipment rental. Its own page describes its history and services; those claims are attributed to the company, not independently verified. Source: https://www.soundwavezam.com/
- **Puzzlepie Zambia** describes event rentals and media production, with technical disciplines including lighting, sound and presentation technology. Its site also presents a broader international group context. Source: https://www.puzzlepie.co.zm/
- **R&G Events** separates public/large-scale productions, corporate functions, private functions and equipment hire. That is a useful information-architecture reference: organise around event context as well as gear. Source: https://www.randgevents.com/services
- **Zirbo Zambia** is listed in a business/industry directory for equipment hire, installation, maintenance and event production. Directory information can be incomplete or stale, so it is used only as a discovery reference. Source: https://www.infobwana.com/directory/zirbo-zambia-ltd

**Differentiation opportunity (design assumption):** FREQ. is positioned as a technical production partner with a transparent planning method and clear scope. The concept avoids claiming the biggest inventory or a record number of events.

## 7. Safety and regulatory context

Safety is a core part of the service, not a decorative badge. The UK Health and Safety Executive's event guidance discusses temporary demountable structures and electrical safety. Its electrical guidance specifically calls out site layout, power requirements, generators, earthing, cable routing, access restriction and protection from weather. Its venue/site design guidance covers audience profile, access, emergency plans, capacity, circulation, ground conditions and site plans. These are useful professional planning references, but they are UK guidance and are **not a substitute for Zambian law or competent local engineering advice**.

The Event Safety Alliance describes its Event Safety Guide as covering emergency planning, crowd management, weather preparedness, communications, venue/site design, rigging and temporary staging. Its ANSI standards list includes guidance for event rigging and temporary special-event structures. Standards may be paywalled and their applicability depends on jurisdiction and scope; this report does not reproduce or certify compliance with them.

For Zambia, the eRegistry explains that required business licences and permits depend on the activity and jurisdiction. Lusaka City Council publishes venue-hire information for community halls and centres. An organiser should confirm current requirements with the relevant council, venue, police and other authorities for the exact event, location, audience and activities. This website does not provide legal advice and does not assert a universal event-permit checklist.

## 8. Sources checked on 27 November 2026

### Local market references
- Soundwave Zambia, services and company profile: https://www.soundwavezam.com/
- Puzzlepie Zambia, event rental and media production: https://www.puzzlepie.co.zm/
- R&G Events, service categories: https://www.randgevents.com/services
- Infobwana directory listing for Zirbo Zambia (secondary directory; verify details directly): https://www.infobwana.com/directory/zirbo-zambia-ltd

### Safety and site planning
- UK HSE, Temporary demountable structures: https://www.hse.gov.uk/event-safety/temporary-demountable-structures.htm
- UK HSE, Electrical safety at events: https://www.hse.gov.uk/event-safety/electrical-safety.htm
- UK HSE, Venue and site design: https://www.hse.gov.uk/event-safety/venue-site-design.htm
- Event Safety Alliance, Standards and Guidance: https://eventsafetyalliance.org/standards-guidance-2

### Zambia context
- Zambia Business Regulatory Review Agency eRegistry, licensing overview: https://businesslicenses.gov.zm/
- Lusaka City Council, Hire a Venue: https://www.lcc.gov.zm/hire-a-venue/
- Lusaka City Council, Contact Us: https://www.lcc.gov.zm/contact-us/

## 9. Sourced facts vs. design assumptions

**Sourced:** Local providers publicly advertise combinations of audio, lighting, stage, LED/video and event production; HSE and Event Safety Alliance guidance treat temporary structures, power, site layout, weather, crowd movement and emergency planning as relevant event-safety topics; Zambia's eRegistry says licence/permit needs depend on activity and jurisdiction; Lusaka City Council publishes venue-hire information.

**Design assumptions:** The fictional company name, address, service radius, team, inventory categories, packages, project examples, prices (none are quoted), testimonials, policies, response times and proposed workflow are invented for this portfolio. No actual licence, insurance, certification, equipment stock, client relationship or event delivery is claimed.

## 10. Strategic conclusion

A credible website in this niche should sell preparation and coordination rather than spectacle alone. The strongest experience is a clear technical service map, event-format routing, transparent pre-production steps, realistic fictional case studies, a practical enquiry builder and an explicit note that final design, rigging, electrical and permit requirements are determined after venue review by competent people and relevant authorities.
